#!/bin/bash

changed=0
while read file ; do
    if [[ "$file" =~ ".ipynb" ]] ; then
        if diff <(cat "$file" | ~/bin/suppress_notebook_output.py) <(git show ":0:${file}") > /dev/null ; then
            echo -n ""
        else
            changed=1
            # echo -n "(changed) "
            # echo $changed
        fi
    else
        # echo -n "not-notebook " ;
        changed=1
    fi ;
    # echo $file ;
done < <(git diff-files --name-only)

exit $changed
