# 4C16 Lab 3 -- classifier comparison

def question_1():
    # This function should return a string.
    # Uncomment the correct answer.
    #
    # Yes, you could try them each in turn..!
    # But don't do that.
    return "Nearest Neighbors"   # Placeholder
    # return "Nearest Neighbors"
    # return "Logistic Regression"
    # return "Linear SVM"
    # return "RBF SVM"
    # return "Decision Tree"

def question_2():
    # This function returns a single number,
    # corresponding to the answer.
    return 1.35 # Replace with your answer.

def question_3():
    # This function returns a single number,
    # corresponding to the answer (0--100)
    return 6.799999999999995 # Replace with your answer.

def question_4():
    # This function returns a single number, corresponding to the
    # digit most commonly misclassified.
    return 9 # Replace with your answer.
