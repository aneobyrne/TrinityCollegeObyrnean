import os
import csv
import torch
from torch.utils.data import Dataset
from pathlib import Path
import torchaudio  
import random
import torchaudio.transforms as T

# -----------------------------------------------------------------------------
# DATASET IMPLEMENTATION NOTES
#
# - The dataset may return multiple features (e.g., waveform, spectrogram,
#   loudness estimate, embeddings, etc.).
#
# - All returned features must have consistent shapes within a batch.
#   Different feature types may have different shapes from each other, but the
#   *same* feature type must have the *same shape* across all samples in the batch.
#   (Example: if feature1 is a raw waveform, each feature 1 should be 
#   padded/cropped to N samples.
#
# - If applying random transforms (noise, time-shift, gain, etc.), only do so
#   when `self.training_flag` is True to ensure evaluation is deterministic.
#
# REQUIREMENTS FOR EVALUATION:
# We will test you dataset. Ensure the following:
#   1) The label is the last returned item. 
#      e.g. return feature1, feature2, label
#   2) All returned items are PyTorch tensors.
#   3) `self.class_names` contains the sorted unique class names.
#   4) Any augmentation or preprocessing happens inside the dataset, not in
#      external training/evaluation loops.
# -----------------------------------------------------------------------------
# Class that loads audio files with labes and converst to tensor for our network
class LoadAudio(Dataset):
    def __init__(self, root_dir, meta_filename, audio_subdir, training_flag: bool = True, waveform_length: int = 220500):
        """
        Args:
            root_dir (str): Dataset root directory.
            meta_filename (str): Metadata filename inside root_dir.
            audio_subdir (str): Audio subdirectory relative to root_dir.
            training_flag (bool): When True, random transforms may be applied
                                  inside __getitem__ for data augmentation.
        """
        # 1) Store the directories/paths.
        # 2) Scan audio_subdir for candidate files.
        # 3) Read metadata: filename + label string → keep only valid files.
        # 4) Construct `self.class_names` (sorted unique labels) and then
        #    `self.label_to_idx` (class_name → integer index).
        # 5) Store samples as list of (filepath, label_string).
        self.training_flag = training_flag
        self.waveform_length = waveform_length

        # Find audio files in the folder
        root = Path(root_dir).resolve()
        audio_dir = root / audio_subdir
        meta_path = root / meta_filename

        # Read metadata that contains labels
        self.meta = {}
        with meta_path.open() as fh:
          for line in fh:
            rel_path, label, clip_id = line.strip().split("\t")
            self.meta[rel_path] = {"label": label, "clip_id": clip_id}
        
        # Keep audio files that exist in metadata
        self.samples = []
        for audio_file in audio_dir.glob("*.wav"):
            rel_path = audio_file.relative_to(root).as_posix()
            if rel_path in self.meta:
                label_str = self.meta[rel_path]["label"]
                self.samples.append((audio_file, label_str))

        # Build class names and label mapping
        self.class_names = sorted(list({label for _, label in self.samples}))
        self.num_classes = len(self.class_names)
        self.label_to_idx = {label: idx for idx, label in enumerate(self.class_names)}

        # Create MelSpectrogram transform 
        self.melspec = torchaudio.transforms.MelSpectrogram(
            sample_rate=44100,
            n_fft=1024,
            hop_length=512,
            n_mels=128
        )

    def __len__(self): # How many audio clips in dataset
        return len(self.samples)

    def __getitem__(self, idx):
        # Pick file at index
        filepath, label_str = self.samples[idx]

        # Load waveform
        waveform, sr = torchaudio.load(filepath)

        # Convert to mono if stereo (2 channels to 1)
        if waveform.shape[0] > 1:
            waveform = torch.mean(waveform, dim=0, keepdim=True)
        
        # Apply AUGMENTATIONS during training
        if self.training_flag:
            # 1. Random gain (sound lvl increase/decrease)
            gain = random.uniform(0.8, 1.2)
            waveform = waveform * gain
            # 2. Adding random noise (noise simulation)
            # noise = torch.randn_like(waveform) * 0.005
            # waveform = waveform + noise
            # 3. Random time shift (audio start changes)
            # max_shift = int(0.05 * waveform.shape[1])
            # shift = random.randint(-max_shift, max_shift)
            # waveform = torch.roll(waveform, shifts=shift, dims=1)
            # 4. Random speed change (faster/slower)
            # speed_factor = random.uniform(0.9, 1.1)
            # if speed_factor != 1.0:
                # new_sr = int(sr * speed_factor)
                # waveform = torchaudio.functional.resample(waveform, orig_freq=sr, new_freq=new_sr)
                # sr = new_sr
        
        # Ensure fixed length (Pad with zeros at the end if short)
        if waveform.shape[1] < self.waveform_length:
            pad_len = self.waveform_length - waveform.shape[1]
            waveform = torch.nn.functional.pad(waveform, (0, pad_len))
        elif waveform.shape[1] > self.waveform_length:
            # Crop randomly
            start = random.randint(0, waveform.shape[1] - self.waveform_length)
            waveform = waveform[:, start:start+self.waveform_length]
        
        #  Convert waveform Mel-Spectogram
        mel = self.melspec(waveform)     # (1, 128, time)
        mel = torchaudio.functional.amplitude_to_DB(mel, multiplier=10.0, amin=1e-10, db_multiplier=0)

        waveform = mel
        
        # Convert label string to index
        label_idx = self.label_to_idx[label_str]
        
        return waveform, label_idx
