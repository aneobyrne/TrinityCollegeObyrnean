import torch
import torch.nn as nn
import torch.nn.functional as F
# -----------------------------------------------------------------------------
# MODEL IMPLEMENTATION NOTES
#
# Goal:
#   Build a model that consumes the audio features produced by `LoadAudio`
#   and outputs logits over the audio scene classes.
#
# Features:
#   - You may pass *multiple* features from the DataLoader  
#     Keep their order consistent with the dataset.
#   - Example loader usage:
#         for (feat1, feat2, labels) in loader:
#             logits = model(feat1, feat2)
#
# 1D vs 2D:
#   - Starting with 1D raw waveforms is fine.
#   - Converting to 2D (Spectrograms / Mel-Spectrograms) is common and often
#     improves performance; design the network (e.g., CNNs) to match the feature
#     dimensionality.
#
# Evaluation requirements:
#   - Forward must accept features in the same order they are yielded by the dataset.
#   - Your model must have ≤ 5M trainable parameters (enforced during review).
# -----------------------------------------------------------------------------
# TODO: design and implement a better model
class AudioClassifier(nn.Module):
    def __init__(self, num_classes: int):
        super().__init__()
        
        # Input shape: [B, 1, 128, T]
        self.conv_block1 = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, padding=1),   # [B,32,128,T]
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d((2, 2)),                        # [B,32,64,T/2]
        )

        self.conv_block2 = nn.Sequential(
            nn.Conv2d(32, 64, kernel_size=3, padding=1), # [B,64,64,T/2]
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d((2, 2)),                        # [B,64,32,T/4]
        )

        self.conv_block3 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),# [B,128,32,T/4]
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d((2, 2)),                        # [B,128,16,T/8]
        )

        self.conv_block4 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.MaxPool2d((2, 2)),                        # [B,256,8,T/16]
        )

        # Adaptive pool: fixed-size vector regardless of T
        self.global_pool = nn.AdaptiveAvgPool2d((1, 1))  # [B,256,1,1]

        # FC layers
        self.fc1 = nn.Linear(256, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.conv_block1(x)
        x = self.conv_block2(x)
        x = self.conv_block3(x)
        x = self.conv_block4(x)

        x = self.global_pool(x)      # [B,256,1,1]
        x = x.view(x.size(0), -1)    # [B,256]

        x = F.relu(self.fc1(x))
        x = self.fc2(x)

        return x