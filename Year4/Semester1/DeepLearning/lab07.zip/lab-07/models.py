import torch                                      # The main PyTorch library
import torch.nn as nn                             # Contains pytorch network building blocks (e.g., layers)
import torch.nn.functional as F                   # Contains functions for neural network operations (e.g., activation functions)

class SuperResolutionModel(nn.Module):
     # x4 Resolution model:
     # Input: (Batch, 3, 32, 32)
     # Output: (Batch, 3, 128, 128)
     # Paramenters: Under 5M
     # Time: ??
    
    def __init__(self):
      super().__init__()
      # Layer 1: 3 channel input, produces 64 feature maps using 5x5 kernel (info capture) and padding 2 to keep same size (32x32)
      self.conv1 = nn.Conv2d(3, 64, kernel_size=5, padding=2)
      # Layer 2: 64 to 64 feature maps with 3x3 kernel and maintaining image size
      self.conv2 = nn.Conv2d(64, 64, kernel_size=3, padding=1)
      # Layer 3: Another 3x3 convoluton for more features
      self.conv3= nn.Conv2d(64, 64, kernel_size=3, padding=1)
      # Upsampling image (x4): channels = outchannels * upscale^2
      self.conv_up = nn.Conv2d(64, 3*4*4, kernel_size=3, padding=1)
      self.pixel_shuffle = nn.PixelShuffle(upscale_factor=4)
    
    def forward(self, x):
      # Define the forward pass of your network here
      x = F.relu(self.conv1(x))
      x = F.relu(self.conv2(x))  
      x = F.relu(self.conv3(x))
      x = self.conv_up(x)
      x = self.pixel_shuffle(x)
     
      return x
